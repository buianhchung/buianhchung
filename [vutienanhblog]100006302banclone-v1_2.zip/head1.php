<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; UTF-8" />
    <meta property="og:image" content="https://imageshack.com/a/img922/4429/Caqi8m.jpg" />
    <title>Bán Clone - Token Facebook - Buff sub - Buff Like - Hack like facebook - hack like - auto like facebook - tăng like facebook - web hack like facebook - tang like facebook</title>
    <meta name="keywords" content="hack like facebook, hack like, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb Bán Token Giá rẻ - Token VipLike Giá Rẻ - Bán CLone Facebook Giá rẻ - banclone.store" />
    <meta name="description" content="hack like facebook, hack like, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />
    <meta name="Classification" content="hack like facebook, hack like, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />
    <meta name="page-topic" content="hack like facebook, hack like, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
    <link rel="shortcut icon" href="http://banclone.store/ban-clone-hack-like-facebook-icon.png"/>
    <meta http-equiv="content-language" content="vi" />
    <meta name="geo.placename" content="Viet Nam" />
    <meta name="author" content="banclone.store" />
    <meta name="copyright" content="Copyright (c) by banclone.store - 2018" />
    <meta name="description" content="Hệ Thống Bán token tự động - Bán Token Giá rẻ" />
</head>
<style>
    body {
        padding-top: 60px;
    }
</style>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            <a class="navbar-brand" href="/"><span class="_2md">TRANG CHỦ</span></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

<ul class="nav navbar-nav navbar-right">
            <li><a href="/checklive.php">Check Live</a></li>
            <li><a href="/cookie.php">Chuyển Token Thành Cookie Login</a></li>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>
<body>
    <style>
        #fountainG {
            position: relative;
            width: 198px;
            height: 24px;
            margin: auto;
        }
        .fountainG {
            position: absolute;
            top: 0;
            background-color: rgb(245, 5, 217);
            width: 24px;
            height: 24px;
            animation-name: bounce_fountainG;
            -o-animation-name: bounce_fountainG;
            -ms-animation-name: bounce_fountainG;
            -webkit-animation-name: bounce_fountainG;
            -moz-animation-name: bounce_fountainG;
            animation-duration: 0.775s;
            -o-animation-duration: 0.775s;
            -ms-animation-duration: 0.775s;
            -webkit-animation-duration: 0.775s;
            -moz-animation-duration: 0.775s;
            animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            -ms-animation-iteration-count: infinite;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            animation-direction: normal;
            -o-animation-direction: normal;
            -ms-animation-direction: normal;
            -webkit-animation-direction: normal;
            -moz-animation-direction: normal;
            transform: scale(.3);
            -o-transform: scale(.3);
            -ms-transform: scale(.3);
            -webkit-transform: scale(.3);
            -moz-transform: scale(.3);
            border-radius: 16px;
            -o-border-radius: 16px;
            -ms-border-radius: 16px;
            -webkit-border-radius: 16px;
            -moz-border-radius: 16px;
        }
        #fountainG_1 {
            left: 0;
            animation-delay: 0.316s;
            -o-animation-delay: 0.316s;
            -ms-animation-delay: 0.316s;
            -webkit-animation-delay: 0.316s;
            -moz-animation-delay: 0.316s;
        }
        #fountainG_2 {
            left: 25px;
            animation-delay: 0.3925s;
            -o-animation-delay: 0.3925s;
            -ms-animation-delay: 0.3925s;
            -webkit-animation-delay: 0.3925s;
            -moz-animation-delay: 0.3925s;
        }
        #fountainG_3 {
            left: 49px;
            animation-delay: 0.469s;
            -o-animation-delay: 0.469s;
            -ms-animation-delay: 0.469s;
            -webkit-animation-delay: 0.469s;
            -moz-animation-delay: 0.469s;
        }
        #fountainG_4 {
            left: 74px;
            animation-delay: 0.5455s;
            -o-animation-delay: 0.5455s;
            -ms-animation-delay: 0.5455s;
            -webkit-animation-delay: 0.5455s;
            -moz-animation-delay: 0.5455s;
        }
        #fountainG_5 {
            left: 99px;
            animation-delay: 0.622s;
            -o-animation-delay: 0.622s;
            -ms-animation-delay: 0.622s;
            -webkit-animation-delay: 0.622s;
            -moz-animation-delay: 0.622s;
        }
        #fountainG_6 {
            left: 124px;
            animation-delay: 0.6985s;
            -o-animation-delay: 0.6985s;
            -ms-animation-delay: 0.6985s;
            -webkit-animation-delay: 0.6985s;
            -moz-animation-delay: 0.6985s;
        }
        #fountainG_7 {
            left: 148px;
            animation-delay: 0.775s;
            -o-animation-delay: 0.775s;
            -ms-animation-delay: 0.775s;
            -webkit-animation-delay: 0.775s;
            -moz-animation-delay: 0.775s;
        }
        #fountainG_8 {
            left: 173px;
            animation-delay: 0.8615s;
            -o-animation-delay: 0.8615s;
            -ms-animation-delay: 0.8615s;
            -webkit-animation-delay: 0.8615s;
            -moz-animation-delay: 0.8615s;
        }
        @keyframes bounce_fountainG {
            0% {
                transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-o-keyframes bounce_fountainG {
            0% {
                -o-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -o-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-ms-keyframes bounce_fountainG {
            0% {
                -ms-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -ms-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-webkit-keyframes bounce_fountainG {
            0% {
                -webkit-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -webkit-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-moz-keyframes bounce_fountainG {
            0% {
                -moz-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -moz-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
    </style>
   