<?php
set_time_limit(0); 
require("../config.php");
$get =mysqli_query($ketnoi,"SELECT `token` FROM `token`");
while($a = mysqli_fetch_assoc($get))
{
	$token = $a['token'];
	$me = json_decode(file_get_contents('https://graph.facebook.com/me?access_token='.$token),true);
	if(!$me['id'])
	{
		mysqli_query($ketnoi,"DELETE FROM `token` WHERE `token` = '".$token."'");
	}else{
		echo $token.'</br>';
	}

}
?>