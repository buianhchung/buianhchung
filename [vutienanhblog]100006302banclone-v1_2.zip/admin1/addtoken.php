<?php
include('../config.php');
if(isset($_GET['token'])){
	$token = $_GET['token'];
	$loai = $_GET['loai'];
	$token2 = $token;
		if( $loai == 1|$loai == 2){
$token2 = explode("|",$token)[4];
	}
	$me = json_decode(file_get_contents('https://graph.facebook.com/me?access_token='.$token2),true);
	if(isset($me['id']) && !preg_match('|@tfbnw.net|',$me['email'])){
			
			if($loai == 1){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `idfb` = '".$me['id']."' AND `loai` = '1'"))) {
				mysqli_query($ketnoi,"UPDATE `token` SET `token` = '".$token."' WHERE `idfb` = ".$me['id']."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `token` SET `idfb` = '".$me['id']."',`token` = '".$token."',`loai` = '1'");
				echo 'insert';
			}
			}
			if($loai == 2){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `idfb` = '".$me['id']."' AND `loai` = '2'"))) {
				mysqli_query($ketnoi,"UPDATE `token` SET `token` = '".$token."' WHERE `idfb` = ".$me['id']."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `token` SET `idfb` = '".$me['id']."',`token` = '".$token."',`loai` = '2'");
				echo 'insert';
			}
			}
			if($loai == 3){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `idfb` = '".$me['id']."'  AND `loai` = '3'"))) {
				mysqli_query($ketnoi,"UPDATE `token` SET `token` = '".$token."' WHERE `idfb` = ".$me['id']."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `token` SET `idfb` = '".$me['id']."',`token` = '".$token."',`loai` = '3'");
				echo 'insert';
			}
			}
			if($loai == 4){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `idfb` = '".$me['id']."'  AND `loai` = '4'"))) {
				mysqli_query($ketnoi,"UPDATE `token` SET `token` = '".$token."' WHERE `idfb` = ".$me['id']."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `token` SET `idfb` = '".$me['id']."',`token` = '".$token."',`loai` = '4'");
				echo 'insert';
			}
			}
			if($loai == 5){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `idfb` = '".$me['id']."'  AND `loai` = '5'"))) {
				mysqli_query($ketnoi,"UPDATE `token` SET `token` = '".$token."' WHERE `idfb` = ".$me['id']."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `token` SET `idfb` = '".$me['id']."',`token` = '".$token."',`loai` = '5'");
				echo 'insert';
			}
			}
			
	}
	exit();
}
include('../head.php');
?>
    <div class="container">
        <div class="col-sm-12 col-xs-12">
            <div class="panel panel-info">
                <div class="panel-heading">ADD TOKEN
                </div>
                <div class="panel-body">
				<div class="form-group">
					<textarea rows="10" cols="50" type="text" class="form-control" id="listtoken"  placeholder="list token mỗi token một dòng"></textarea>
					</div>
					
					<div class="form-group has-error has-feedback">
            <select id="loai" class="form-control">
		    <option value="1">Clone - Token Full Quyền Veri Mail </option>
			<option value="2">Clone - Token Không Veri Mail </option>
			<option value="3">Clone - Token Random 1000 5000 bạn bè</option>
			<option value="4">Token - noveri  </option>
			<option value="5">Token - Veri </option>
		</select>
        </div>
					<div class="form-group">
						<button type="button" class="btn btn-primary" id="btn" onclick="addtoken();">Add Token</button>
					</div>
					<div id='an' style= 'display:none'>
					Số Token update :<div id='update'>0</div>
					Số Token insert :<div id='insert'>0</div>
					Số Token Die :<div id='die'>0</div>
					</div>
                </div>
            </div>
        </div>
<script type="text/javascript">
    function addtoken() {
		var insert = 0, update = 0, die = 0;
        var listtoken = $('#listtoken').val();
		var loai = $('#loai').val();
        if (listtoken == '') {
            toarst("error", "Vui Lòng Nhập list token", "Thông Báo Lỗi !!!");
            return false;
        }
		$('#an').show();
		$('#btn').prop('disabled', true)
		var token = listtoken.split('\n');
		var c = token.length;
		for(i = 0; i < c; i++){
		var vuong = token[i].trim();
        $.get('addtoken.php', {
            token: vuong,
			loai:loai
        }, function(data, status) {
			if(data == '')
			{
				die++;
				$('#die').text(die);
			}
			if(data == 'insert')
			{
				insert++;
				$('#insert').text(insert);	
			}
			if(data == 'update')
			{
				update++;
				$('#update').text(update);
			}
           $('#btn').prop('disabled', false)
        });
		}
    }
</script>
<?php
include('../foot.php');
?>