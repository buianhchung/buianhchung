<?php
session_start();
if ($_POST && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest' && isset($_SESSION['username']) && isset($_POST['soluong']) && $_POST['soluong'] > 1 && is_numeric($_POST['soluong'])){
	include('config.php');
	$soluong = $_POST['soluong'];
	$loai = $_POST['loai'];
	if($loai == 1){
		$gia =$gia1;
	$tongtoken = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '1'"));
	}else if($loai == 2){
		$gia =$gia2;
	$tongtoken = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '2'"));
    }else if($loai == 4){
		$gia =$gia4;
	$tongtoken = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '4'"));
    }else if($loai == 5){
		$gia =$gia5;
	$tongtoken = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '5'"));
	}else{
		$gia =$gia3;
	$tongtoken = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '3'"));
	}
	if($soluong > $tongtoken){
		exit('<b style="color:red">Số Lượng Token Không Được Lớn hơn Số Token Đang Có Ở Hệ Thống !!!</b>');
	}
	$username = $_SESSION['username'];
	$vnd = mysqli_fetch_assoc(mysqli_query($ketnoi,"SELECT `VND` FROM `account` WHERE `username` = '".$_SESSION['username']."'"))['VND'];
	$thanhtien = $soluong * $gia;
	if($thanhtien > $vnd){
		exit('<b style="color:red">Bạn Không Đủ Tiền Để Mua Số Lượng Token Này Vui Lòng Nạp Thêm !!!</b>');
	}
	$time = time();
	mysqli_query($ketnoi,"UPDATE `account` SET `VND` = `VND` - ".$thanhtien." WHERE `username` = '".$username."'");
		if($loai == 1){
	$get = mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `loai` = '1' ORDER BY RAND() LIMIT 0, {$soluong}");
	}else if($loai == 2){
	$get = mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `loai` = '2' ORDER BY RAND() LIMIT 0, {$soluong}");
    }else if($loai == 4){
	$get = mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `loai` = '4' ORDER BY RAND() LIMIT 0, {$soluong}");
	}else if($loai == 5){
	$get = mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `loai` = '5' ORDER BY RAND() LIMIT 0, {$soluong}");
	}else{
	$get = mysqli_query($ketnoi,"SELECT * FROM `token` WHERE `loai` = '3' ORDER BY RAND() LIMIT 0, {$soluong}");
	}
	
		if($get)
		{
			
			$fail = 0;
			while($row = mysqli_fetch_assoc($get))
			{
			$token = $row['token'];
			$idfb = $row['idfb'];
			mysqli_query($ketnoi,"DELETE FROM `token` WHERE `token` ='".$token."'");
			$token2 = $token;
			if($loai == 1 |$loai == 2){
				$token2 = explode("|",$token)[4];
			}
			$check123 = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$token2.''), true);
			if($check123['id']){
			mysqli_query($ketnoi,"INSERT INTO `token_sell` SET `token` = '".$token."',`idfb` = '".$idfb."',`time` = '".$time."',`username` = '".$username."'");
		}else{
			$fail = $fail + 1;
}
			}
				$hoantien  = $gia * $fail;
				mysqli_query($ketnoi,"UPDATE `account` SET `VND` = `VND` + ".$hoantien." WHERE `username` = '".$username."'");

	$success = $soluong - $fail;
		mysqli_query($ketnoi,"INSERT INTO `lich_su_mua` SET `count_token` = '".$success."',`time` = '".$time."',`username` = '".$username."'");

	$tienmua = $gia * $success;

		}
		
		exit('<b style="color:green">Mua '.$success.' Token Thành Công Trừ '.$tienmua.' VND Token Của Bạn Được Lưu Tại <a href="oday.php?time='.$time.'">Đây</a>!!!</b>');
}
?>