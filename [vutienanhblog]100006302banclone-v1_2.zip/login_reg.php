<?php
session_start();
require("config.php");
date_default_timezone_set("Asia/Ho_Chi_Minh");
if ($_POST && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
if(empty($_POST['username']) || empty($_POST['password'])){
exit();
}
$username = addslashes($_POST['username']);
$password = addslashes($_POST['password']);
if(strlen($password) < 6 || strlen($password) > 32 || strlen($username) < 6 || strlen($username) > 32)
{
	die('<script type="text/javascript">toarst("error","Tài Khoản Và mật khẩu phải từ 6 - 32 ký tự !!!","Thông Báo Lỗi");</script>');
}
$dem = mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `account` WHERE `username` ='".mysqli_real_escape_string($ketnoi,$username)."'"));
if($dem == 1){
	$dem = mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `account` WHERE `username` ='".mysqli_real_escape_string($ketnoi,$username)."' AND `password` = '".mysqli_real_escape_string($ketnoi,$password)."'"));
	if($dem == 1){
	$_SESSION['username'] = $username;
	die('<script type="text/javascript">toarst("success","Đăng Nhập Thành Công !!! Hệ Thống Chuyển Hướng Sau 3s...","Thông Báo"); setTimeout(function(){ location.href = "/home.php" },2000);</script>');
	}else{
		die('<script type="text/javascript">toarst("error","Tài Khoản Hoặc Mật Khẩu Của Bạn Chưa Chính Xác","Thông Báo Lỗi");</script>');
	}
}
else
{
	$_SESSION['username'] = $username;
mysqli_query($ketnoi,"INSERT INTO account SET `username` = '".mysqli_real_escape_string($ketnoi,$username)."',`password` = '".mysqli_real_escape_string($ketnoi,$password)."',`VND` = '10'");
die('<script type="text/javascript">toarst("success","Đăng Ký Thành Công !!! Hệ Thống Chuyển Hướng Sau 3s...","Thông Báo"); setTimeout(function(){ location.href = "/home.php" },2000);</script>');
}
}
?>