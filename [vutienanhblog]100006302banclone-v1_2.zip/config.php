<?php
// kết nối database .
define("DATABASE", "dgnxumqehosting_token");
define("USERNAME", "dgnxumqehosting_token");
define("PASSWORD", "01693606162ad");
define("LOCALHOST", "localhost");
$ketnoi = mysqli_connect(LOCALHOST,USERNAME,PASSWORD,DATABASE);
mysqli_query($ketnoi,"set names 'utf8'");  
// config thông tin web
$sdt = ""; // số điện thoại admin.
$name = "Tạ Đức Phương"; // tên admin.
$idfb = "messages/t/taducphuong.tn"; // idfb admin để liên hệ.
$gia1 = 350; // giá mỗi token.
$gia2 = 100; // giá mỗi token.
$gia3 = 5000; // giá mỗi token.
$gia4 = 100; // giá mỗi token.
$gia5 = 300; // giá mỗi token.
?>