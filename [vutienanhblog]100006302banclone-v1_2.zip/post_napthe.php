<?php
session_start();
include 'config.php';
        $mtop_username = "1"; // tên đăng nhập
        $mtop_password = "1"; // mật khẩu
        $mtop_stk = "1"; // số tài khoản
        $mang  = $_POST['mang'];
        $sopin = $_POST['mathe'];
        $seri  = $_POST['seri'];
        $result = curl('https://my.mtop.vn/dang-nhap');
        $cookie = getcookie($result[0]);
        $pass = md5($mtop_password);
        $post = "username=$mtop_username&password=$pass";
        $result = curl('https://my.mtop.vn/login',$post,'',$cookie);
        $cookie = getcookie($result[0]);
        $result = curl('https://my.mtop.vn/',false,'',$cookie);
        $result = curl('https://my.mtop.vn/thong-tin-ca-nhan/auth-method',false,'',$cookie);
        $post1 = '{"issuer":"'.$mang.'","cardSerial":"'.$seri.'","cardCode":"'.$sopin.'","accountNo":"'.$mtop_stk.'"}';
        $result1 = curl_json('https://my.mtop.vn/giao-dich/nap-tien-bang-the-cao',$post1,'',$cookie);        
        $response = json_decode($result1[1],true);
        
date_default_timezone_set('Asia/Ho_Chi_Minh');
$time = time();
$status = $response['code'];
if($status=='01'){
    $amount = $response['data']['price']; // tiền
	mysqli_query($ketnoi,"UPDATE `account` SET VND = VND + $amount WHERE username  = '".$_SESSION['username']."'");
	$dem = mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `top_nap` WHERE `username` = '".$_SESSION['username']."'"));
	if($dem > 1){
	mysqli_query($ketnoi,"UPDATE `top_nap` SET total_amount = total_amount + $amount WHERE username  = '".$_SESSION['username']."'");
	}else{
	mysqli_query($ketnoi,"INSERT INTO `top_nap` SET `total_amount` = '".$amount."',`username` = '".$_SESSION['username']."'");
	}
	echo '<script>toarst("success"," Nạp Thẻ Thành Công Với Mệnh giá '.$amount.'","Thông Báo");</script>';

}
else{ 
$err = isset($response['message']) ? $response['message'] : 'Nạp thẻ không thành công';
	echo '<script>toarst("error","'.$err.'","Thông Báo");</script>';
}


       function curl($url,$post = false,$ref = '', $cookie = false,$cookies = false,$header = true,$headers = false,$follow = false)
        {
            $ch=curl_init($url);
            if($ref != '') {
                curl_setopt($ch, CURLOPT_REFERER, $ref);
            }
            if($cookie){
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
            }
            if($cookies)
            {
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
            }
            if($post){
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_setopt($ch, CURLOPT_POST, 1);
            }
              curl_setopt($ch, CURLOPT_HEADER, 1);
            if($headers)        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_ENCODING, '');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            $result[0] = curl_exec($ch);
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $result[1] = substr($result[0], $header_size);
            curl_close($ch);
            return $result;

        }

        function curl_json($url,$post = false,$ref = '', $cookie = false,$cookies = false,$header = true,$headers = false,$follow = false)
        {
            $ch=curl_init($url);
            if($ref != '') {
                curl_setopt($ch, CURLOPT_REFERER, $ref);
            }
            if($cookie){
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
            }
            if($cookies)
            {
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
            }
            if($post){
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_setopt($ch, CURLOPT_POST, 1);
            }
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($ch, CURLOPT_ENCODING, '');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            $result[0] = curl_exec($ch);
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $result[1] = substr($result[0], $header_size);
            curl_close($ch);
            return $result;

        }


        function getcookie($content){
            preg_match_all('/Set-Cookie: (.*);/U',$content,$temp);
            $cookie = $temp[1];
            $cookies = "";
            $a = array();
            foreach($cookie as $c){
                $pos = strpos($c, "=");
                $key = substr($c, 0, $pos);
                $val = substr($c, $pos+1);
                $a[$key] = $val;
            }
            foreach($a as $b => $c){
                $cookies .= "{$b}={$c};";
            }
            return $cookies;
        }
