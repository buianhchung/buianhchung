<?php
session_start();
require('config.php');
if(isset($_POST['mess'])){
		$username = $_SESSION['username'];
        $message = htmlentities($_POST["mess"]);
		$xxx=array('taducphuong','Taducphuong','admin','Tạ Đức Phương','Ta duc Phuong
		','đéo','scam','Đm','dcm','up scam','muatoken.top','Muatoken.Top','vl','fuck','dit','djt','địt','lồn','loz','vc','<script>','cặc','djt','http://MuaToken. Net','.com','.net','.tk','.xyz','www','.info','.org','.me','.top','.ml','.ga','.vn','.lol','.pro','MuaToken. Net','.club','.asia');
		foreach($xxx as $xn=> $mades){
		if(preg_match('|'.$mades.'|',$message)){
		$madesu = true;
		break;
		}
		if($username == 'taducphuong' && $message == '#xoa'){
			mysqli_query($ketnoi,"DELETE FROM `chatbox` ");
			$message = '#xoa <b style=\"color:pink\">'.$username.'</b> Vừa Xóa Chat Box';
		}
}
if($madesu){
echo  '<script type="text/javascript">toarst("success","Không nói bậy .  Không Quảng Cáo. <br> Địt Mẹ Mày Biến Nhé! Thằng Ngu Lồn .","Lời Nhắn")</script>';
}else{
	mysqli_query($ketnoi,'INSERT INTO chatbox(username,message) VALUES ("'.$username.'","'.$message.'")');
	echo '<script type="text/javascript">toarst("success","Gửi Tin Nhắn Thành Công.","Lời Nhắn")</script>';
}
}
			$result = mysqli_query($ketnoi,"SELECT * FROM `chatbox` ORDER BY id DESC LIMIT 0,10 ");
				if($result){
				$array = array();
				while($row = mysqli_fetch_assoc($result)){
					if($row['username'] == 'taducphuong'){
					echo '<li class="list-group-item"><b style="color:pink" data-toggle="tooltip" data-placement="top" title="ADMIN">'.$row['username'].'</b>: <i style="">'.$row['message'].'</i></b></li>';
					}else if($row['username'] == 'vgtran'){
						echo '<li class="list-group-item"><b style="color:blue" data-toggle="tooltip" data-placement="top" title=" MOD+">'.$row['username'].'</b>: <i style="">'.$row['message'].'</i></b></li>';
					}else{
					echo '<li class="list-group-item"><b style="color:black" data-toggle="tooltip" data-placement="top" title="THÀNH VIÊN">'.$row['username'].'</b>: <i style="">'.$row['message'].'</i></b></li>';
					}
				}
				}
?>