<?php
session_start();
if(empty($_SESSION['username'])){
	session_destroy();
	header('location: /');
	die();
}
include('config.php');
include('head.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; UTF-8" />
    <meta property="og:image" content="https://i.imgur.com/C8sT2CY.jpg" />
<title>BÁN CLONE TOKEN TỰ ĐỘNG ADMIN:HOÀNG ĐỨC</title>
<!-- Jquery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet"/>

    <meta name="description" content="" />
<meta name="keywords" content="" />
</head>
<style>
  
  	body {
  	padding-top: 60px;
		}

  </style>

<!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
               
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
              
                <a class="navbar-brand" href="/"><span class="_2md">TRANG CHỦ</span></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">


		    <li>
						<a data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span></a>
                    </li>
                    <li>
                        <a href="/checklive.php">Checklive</a>
                    </li>
                    <li>
                        <a href="https://www.facebook.com/messages/t/taducphuong.tn">Liên hệ ngay Admin</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<body>
<style>
    #fountainG{
        position:relative;
        width:198px;
        height:24px;
        margin:auto;
    }

    .fountainG{
        position:absolute;
        top:0;
        background-color:rgb(245,5,217);
        width:24px;
        height:24px;
        animation-name:bounce_fountainG;
        -o-animation-name:bounce_fountainG;
        -ms-animation-name:bounce_fountainG;
        -webkit-animation-name:bounce_fountainG;
        -moz-animation-name:bounce_fountainG;
        animation-duration:0.775s;
        -o-animation-duration:0.775s;
        -ms-animation-duration:0.775s;
        -webkit-animation-duration:0.775s;
        -moz-animation-duration:0.775s;
        animation-iteration-count:infinite;
        -o-animation-iteration-count:infinite;
        -ms-animation-iteration-count:infinite;
        -webkit-animation-iteration-count:infinite;
        -moz-animation-iteration-count:infinite;
        animation-direction:normal;
        -o-animation-direction:normal;
        -ms-animation-direction:normal;
        -webkit-animation-direction:normal;
        -moz-animation-direction:normal;
        transform:scale(.3);
        -o-transform:scale(.3);
        -ms-transform:scale(.3);
        -webkit-transform:scale(.3);
        -moz-transform:scale(.3);
        border-radius:16px;
        -o-border-radius:16px;
        -ms-border-radius:16px;
        -webkit-border-radius:16px;
        -moz-border-radius:16px;
    }

    #fountainG_1{
        left:0;
        animation-delay:0.316s;
        -o-animation-delay:0.316s;
        -ms-animation-delay:0.316s;
        -webkit-animation-delay:0.316s;
        -moz-animation-delay:0.316s;
    }

    #fountainG_2{
        left:25px;
        animation-delay:0.3925s;
        -o-animation-delay:0.3925s;
        -ms-animation-delay:0.3925s;
        -webkit-animation-delay:0.3925s;
        -moz-animation-delay:0.3925s;
    }

    #fountainG_3{
        left:49px;
        animation-delay:0.469s;
        -o-animation-delay:0.469s;
        -ms-animation-delay:0.469s;
        -webkit-animation-delay:0.469s;
        -moz-animation-delay:0.469s;
    }

    #fountainG_4{
        left:74px;
        animation-delay:0.5455s;
        -o-animation-delay:0.5455s;
        -ms-animation-delay:0.5455s;
        -webkit-animation-delay:0.5455s;
        -moz-animation-delay:0.5455s;
    }

    #fountainG_5{
        left:99px;
        animation-delay:0.622s;
        -o-animation-delay:0.622s;
        -ms-animation-delay:0.622s;
        -webkit-animation-delay:0.622s;
        -moz-animation-delay:0.622s;
    }

    #fountainG_6{
        left:124px;
        animation-delay:0.6985s;
        -o-animation-delay:0.6985s;
        -ms-animation-delay:0.6985s;
        -webkit-animation-delay:0.6985s;
        -moz-animation-delay:0.6985s;
    }

    #fountainG_7{
        left:148px;
        animation-delay:0.775s;
        -o-animation-delay:0.775s;
        -ms-animation-delay:0.775s;
        -webkit-animation-delay:0.775s;
        -moz-animation-delay:0.775s;
    }

    #fountainG_8{
        left:173px;
        animation-delay:0.8615s;
        -o-animation-delay:0.8615s;
        -ms-animation-delay:0.8615s;
        -webkit-animation-delay:0.8615s;
        -moz-animation-delay:0.8615s;
    }



    @keyframes bounce_fountainG{
        0%{
            transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-o-keyframes bounce_fountainG{
        0%{
            -o-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -o-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-ms-keyframes bounce_fountainG{
        0%{
            -ms-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -ms-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-webkit-keyframes bounce_fountainG{
        0%{
            -webkit-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -webkit-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-moz-keyframes bounce_fountainG{
        0%{
            -moz-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -moz-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }
</style>
<div class="container">
<title>Nạp Xu</title>
<!-- /seo -->

<div class="col-sm-12 blog-main">
<div class="panel panel-warning">
<div class="panel-heading">
<h3 class="panel-title"><span class="glyphicon glyphicon-qrcode"></span> NẠP XU QUA THẺ CÀO</h3></div>
<div id="bodyupcmt" class="panel-body">

<li class="list-group-item"><font color="red">Chú ý: Hiện tại đang khuyến mãi 0 % giá trị nạp. Chức năng nạp card không hoạt động liên hệ ADMIN để nạp nhé !!!</font></li>
    <pre>
HÌNH THỨC NẠP TIỀN
✓Agri Bank - Số tài khoản : 8507205139771 - Chủ tài khoản : Tạ Đức Phương 
✓Việt Com Bank - Số tài khoản : 0491000119986 - Chủ tài khoản : Tạ Đức Phương 
✓banthe247 : taducphuong1234@gmail.com
✓momo: 01693 60 61 62
Đối với bạn nào ck qua VCB AGI MOMO BANTHE247 nội dung ck ghi TÀI KHOẢN: <font color="red"><b><?php echo $_SESSION['username']; ?> </b></font> để được ưu đãi cao nhất
ck xong tiền sẽ được cộng vào tài khoản nếu không cộng liên hệ admin Tạ Đức Phương hoặc call 01693606162 để được xử lý.
LƯU Ý : LIÊN HỆ ADMIN TRƯỚC KHI NẠP TIỀN ĐỂ ĐƯỢC XỬ LÝ TỐC ĐỘ ANH SÁNG
</pre>
<form class="form-horizontal form-bk" role="form" method="post" action="/napxu/xuly.php">
<div class="form-group">
    <label for="txtpin" class="col-lg-2 control-label">Loại thẻ</label>
    <div class="col-lg-10">
      <select class="form-control" name="nhamang"> 
                                    <option value="VTT">Viettel</option>
                                    <option value="VMS">Mobiphone</option>
                                    <option value="VNP">Vinaphone</option>
                                    <option value="FPT">Gate</option>
                                    <option value="VNM">Vietnammobile</option>
                                    <option value="MGC">Megacard</option>
                                    <option value="ONC">OnCash</option>
		</select>
    </div>
  </div>
      <input type="hidden" class="form-control" id="txtuser" name="user"  value ="<?php echo $_SESSION['username']; ?>" />
  <div class="form-group">
    <label for="txtpin" class="col-lg-2 control-label">Mã thẻ</label>
    <div class="col-lg-10">
      <input type="text" class="form-control" id="txtpin" name="mathe" placeholder="Mã thẻ" data-toggle="tooltip" data-title="Mã số sau lớp bạc mỏng"/>
    </div>
  </div>
  <div class="form-group">
    <label for="txtseri" class="col-lg-2 control-label">Số seri</label>
    <div class="col-lg-10">
      <input type="text" class="form-control" id="txtseri" name="seri" placeholder="Số seri" data-toggle="tooltip" data-title="Mã seri nằm sau thẻ">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary" name="napthe">Nạp thẻ</button>
</div>
</div>
</div>
</form>
</div></div>
    <div class="col-sm-12 blog-main">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <h3 class="panel-title"><span class="glyphicon glyphicon-signal"></span> LỊCH SỬ NẠP</h3>
                <?php
$result = mysqli_query($ketnoi,"SELECT * FROM `top_nap` ORDER BY `total_amount` DESC LIMIT 0,10");
if($result)
{
	$i = 1;
while($row = mysqli_fetch_assoc($result))
{
?>
 <li class="list-group-item"> TOP <?php echo $i.' : '; echo '<b style="color:red">'.$row['username'].'</b>'; ?> TỔNG NẠP : <b style="color:red"><?php echo number_format($row['total_amount']); ?> VNĐ</b></li>
<?php
$i++;
}
}
?>
            </div>

            <div id="bodyupcmt" class="panel-body">
