<?php
session_start();
if(isset($_SESSION['username'])){
	header('location: /home.php');
	die();
}
include('config.php');
include('head1.php');
?>


    <div class="container">
        <div class="col-sm-12 col-xs-16">
            
<div class="row">
<div class="col-sm-12"> 
<br />
<div class="alert alert-success">
     <strong><marquee>KM 20%  ĐỐI VỚI NẠP QUA ATM VIETCOMBANK - AGRIBANK  - MOMO - BANTHE247</marquee></strong>   
</div>
<div class="panel panel-info">
                <div class="panel-heading"><h2>Thống Kê - Hệ Thống Bán Nick Facebook Tự Động.</h2>
                </div>
                <div class="panel-body">
<li class="list-group-item">Clone - Token Full Quyền Veri Mail Còn Lại : <b><font color="red"><?php $tongtoken1 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '1' "));  echo $tongtoken1; ?></font> Acc</b></li>
<li class="list-group-item">Clone - Token Không Veri Mail Còn Lại : <b><font color="red"><?php $tongtoken2 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '2'"));  echo $tongtoken2; ?></font> Acc</b></li>
<li class="list-group-item">Clone - 1000 5000 Bạn Bè Còn Lại : <b><font color="red"><?php $tongtoken3 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '3'"));  echo $tongtoken3; ?></font> Acc</b></li>
<li class="list-group-item">Token - Noveri  Còn Lại : <b><font color="red"><?php $tongtoken4 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '4'"));  echo $tongtoken4; ?></font> Acc</b></li>
<li class="list-group-item">Token - Veri Còn Lại : <b><font color="red"><?php $tongtoken5 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '5'"));  echo $tongtoken5; ?></font> Acc</b></li>
                    <li class="list-group-item"><b><font color="blue">Hệ Thống Đã Bán:</b></font>
                     <b><font color="red"><?php echo mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token_sell`")); ?></b></font>  Acc
                    </li>
<pre>HÌNH THỨC NẠP TIỀN
✓Agri Bank - Số tài khoản : 8507205139771 - Chủ tài khoản : Tạ Đức Phương 
✓Việt Com Bank - Số tài khoản : 0491000119986 - Chủ tài khoản : Tạ Đức Phương 
✓banthe247 : taducphuong1234@gmail.com
✓momo: 01693 60 61 62
Đối với bạn nào ck qua VCB MOMO BANTHE247 nội dung ck ghi tên tài khoản của bạn để được ưu đãi cao nhất
ck xong tiền sẽ được cộng vào tài khoản nếu không cộng liên hệ admin <a href="https://www.facebook.com/taducphuong.tn">Tạ Đức Phương</a> hoặc call <a href="tel:01693606162">01693606162</a> để được xử lý.
LƯU Ý : LIÊN HỆ ADMIN TRƯỚC KHI NẠP TIỀN ĐỂ ĐƯỢC XỬ LÝ TỐC ĐỘ ANH SÁNG
</pre>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">
            <div class="panel panel-info">
                <div class="panel-heading"> ĐĂNG NHẬP ( Đăng Ký )</div>
                <div class="panel-body">
                        <li class="list-group-item">NHẬP USERNAME VÀ PASSWORD WEB TỰ ĐỘNG ĐĂNG NHẬP VÀ ĐĂNG KÝ NHÉ.</li>
                                <div class="form-group has-success has-feedback">
                                    <div class="input-group">
                                        <span class="input-group-addon">Tài khoản</span>
                                        <input type="text" class="form-control" id="user" aria-describedby="inputGroupSuccess3Status">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
                                    </div>
                                </div>
                                <div class="form-group has-error has-feedback">
                                    <div class="input-group">
                                        <span class="input-group-addon">Mật  khẩu</span>
                                        <input type="password" class="form-control" id="pass" aria-describedby="inputGroupSuccess3Status">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
                                    </div>
                                </div>
                                <center><button id="submit" class="btn btn-danger">Đăng Nhập + Đăng ký</button></center>
                    <br />
<pre>
BẢNG GIÁ:
Clone - Token Full Quyền Veri Mail <?php echo $gia1; ?>d/1
Clone - Token Không Veri <?php echo $gia2; ?>d/1
Clone - 1000 5000 Bạn Bè <?php echo $gia3; ?>d/1
Token - Noveri <?php echo $gia4; ?>d/1
Token - Veri <?php echo $gia5; ?>d/1

</pre>
</div>
</div>
</div>
        <div class="col-sm-6 col-xs-12">
            <div class="panel panel-info">
                <div class="panel-heading"> LỊCH SỬ MUA BÁN</div>
                <div class="panel-body">
				<?php
				$result = mysqli_query($ketnoi,"SELECT * FROM `lich_su_mua` ORDER BY id DESC LIMIT 0,10");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
				 <li class="list-group-item"><b><font color="blue"><?php echo date('d-m-Y',$row['time']); ?></font></b> Tài Khoản<b> <font color="red"><?php echo $row['username']; ?></font></b> Đã Mua <b><font color="blue"><?php echo $row['count_token']; ?></font></b> Tài Khoản.</li>
				<?php 
				}
				}
				?>
                </div>
            </div>
        </div>
                    <!-- .et_pb_blurb_content -->
                </div>
                <!-- .et_pb_blurb -->
            </div>
            <!-- .et_pb_column -->
        </div>
<script type="text/javascript">
		$('#submit').click(function(){
			var username = $('#user').val();
			var password = $('#pass').val();
				if (username == '' || password == '') {
					toarst("error","Vui Lòng Nhập Đầy Đủ Thông Tin","Thông Báo");
					return false;
				}
				$('#submit').prop('disabled', true)
				$.post('login_reg.php', {
					username: username,
					password: password
				}, function(data, status) {
					$("#trave").html(data);
					$('#submit').prop('disabled', false);
				});
			});
</script>
<?php
include('foot.php');
?>