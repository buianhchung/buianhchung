<?php
session_start();
if(empty($_SESSION['username'])){
	session_destroy();
	header('location: /');
	die();
}
include('config.php');
include('head.php');
?>
<div class="container">

<div class="container" role="main">
<div class="row">
<div class="col-sm-12"> 
<br />
<div class="alert alert-success">
     <strong><marquee>Hệ Thống Bán Token Người Dùng Hoạt Động ( VIA ) Và Token Verify , No Verify reg Từ 1 tuần , Tháng Hệ Thống Tự Xóa Token Khi Khách Hàng Mua Thành Công Cảm ơn ACE đã ủng hộ !!!</marquee></strong>   
</div>

<div class="col-sm-12 col-xs-12">

<div class="panel panel-info">
<div class="panel-heading"> THÔNG TIN TÀI KHOẢN</div>
<div class="panel-body"><li class="list-group-item">TÀI KHOẢN: <font color="red"><b><?php echo $_SESSION['username']; ?> </b></font> SỐ DƯ <font color="red"><b><?php $vnd = mysqli_fetch_assoc(mysqli_query($ketnoi,"SELECT `VND` FROM `account` WHERE `username` = '".$_SESSION['username']."'"))['VND']; echo $vnd; ?></b></font> VNĐ</li>
<?php
if($_SESSION['username'] == 'taducphuong'){
echo '<li class="list-group-item"><a href="admin1/vnd.php"><font color="red"><b>THÊM TIỀN</b></font></a></li><li class="list-group-item"><a href="admin1/addtoken.php"><font color="red"><b>THÊM CLONE</b></font></a></li>';
}
?>
<li class="list-group-item"><a href="napxu/index.php"><font color="red"><b>Nạp Tiền</b></font></a></li>
<li class="list-group-item">Clone - Token Full Quyền Veri Mail Còn Lại : <b><font color="red"><?php $tongtoken1 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '1' "));  echo $tongtoken1; ?></font> Acc</b></li>
<li class="list-group-item">Clone - Token Không Veri Mail Còn Lại : <b><font color="red"><?php $tongtoken2 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '2'"));  echo $tongtoken2; ?></font> Acc</b></li>
<li class="list-group-item">Clone - Token 1000 5000 Bạn Bè Còn Lại : <b><font color="red"><?php $tongtoken3 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '3'"));  echo $tongtoken3; ?></font> Acc</b></li>
<li class="list-group-item">Token - Noveri  Còn Lại : <b><font color="red"><?php $tongtoken4 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '4'"));  echo $tongtoken4; ?></font> Acc</b></li>
<li class="list-group-item">Token - Veri Còn Lại : <b><font color="red"><?php $tongtoken5 = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `token` WHERE `loai` = '5'"));  echo $tongtoken5; ?></font> Acc</b></li>
 

</div>
</div>
</div>

<div class="col-lg-0 col-lg-6">
<div class="panel panel-info">
<div class="panel-heading">MUA CLONE - TOKEN</div>
<div class="panel-body">
<div class="form-group" id = "mess">
</div>
<div class="form-group">
    <label for="user_name" class="col-sm-3 control-label">Chọn Loại Clone :</label>
    <div class="col-sm-8">
        <div class="form-group has-error has-feedback">
            <select id="loai" class="form-control">
<option value="1">Clone - Token Full Quyền Veri Mail </option>
<option value="2">Clone - Token Không Veri </option>
<option value="3">Clone - Token 1000 5000 Bạn Bè</option>
<option value="4">Token - Noveri </option>
<option value="5">Token - Verify </option>
		</select>
        </div>
    </div>
</div>
<label for="user_name" class="col-sm-3 control-label">Nhập số lượng:</label>
<div class="col-sm-8">
    <input type="number" class="form-control" placeholder="Nhập Số Lượng" min="1" id="soluong">
    <div class="form-group">
        <label class="col-sm-8 control-label">Tổng thanh toán: <font color="red"><b id="tongthanhtoan">0</b></font> VND</label>
    </div>
    
 <center><button id="mua" type="button" class="btn btn-success">Mua Ngay</button></center>
</div>
</div>
</div>
</div>
<div class="col-sm-6 col-xs-12">

<div class="panel panel-info">

<div class="panel-heading"> HƯỚNG DẪN CƠ BẢN</div>

<div class="panel-body">

<li class="list-group-item">Dạng Mặc Định Của Clone Trên Hệ Thống <br> UID | MAIL - SDT | PASS | COOKIE | TOKEN </li>
<li class="list-group-item"> <kbd>Khách hàng mua xong vui lòng check token tại hệ thống để tách token !!! <kbd> </li>
<li class="list-group-item"> Hàng Noveri dùng bao nhiêu lấy tưng đó nhé. tránh chưa dùng đã die. thanks !!!  </li>

<li class="list-group-item"></li>

<li class="list-group-item">&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; CẢM ƠN BẠN ĐÃ SỬ DỤNG DỊCH VỤ &lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;</li>

<li class="list-group-item"><pre>
BẢNG GIÁ:
-----------------------------------------
Clone - Token Full Quyền Veri Mail <?php echo $gia1; ?>d/1
Clone - Token Không Veri <?php echo $gia2; ?>d/1
Clone - 1000 5000 Bạn Bè <?php echo $gia3; ?>d/1
Token - Noveri <?php echo $gia4; ?>d/1
Token - Veri <?php echo $gia5; ?>d/1
</pre>

</li>

</div>

</div>

</div>
<div class="col-sm-12 col-xs-12">
<div class="panel panel-info">
<div class="panel-heading"> CHAT BOX</div>
<div class="panel-body">
<div class="form-group">
<input type="text" class="form-control" id="tinhan" placeholder="Tin nhắn">
</div>

<div class="form-group">
<button id="gui" type="button" class="btn btn-success">Gửi</button>

</div>
<div id="chatbox">
</div>
</div>
</div>
</div>



<div class="col-sm-12 col-xs-12">
<div class="panel panel-info">
<div class="panel-heading"> LỊCH SỬ MUA TOKEN</div>
<div class="panel-body">
<?php
				$result = mysqli_query($ketnoi,"SELECT * FROM `lich_su_mua` WHERE `username` = '".$_SESSION['username']."' ORDER BY id DESC LIMIT 0,10 ");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
				 <li class="list-group-item"><b><font color="blue"><?php echo date('d-m-Y',$row['time']); ?></font></b> Tài Khoản<b> <font color="red"><?php echo $row['username']; ?></font></b> Đã Mua <b><font color="blue"><?php echo $row['count_token']; ?></font></b> Token. Bạn Có Thể Lấy Token Tại <a href="/oday.php?time=<?php echo $row['time']; ?>">Đây</a></li>
				<?php 
				}
				}
				?>
</div>
</div>
</div>

<div class="col-sm-12 col-xs-12">
<div class="panel panel-info">
<div class="panel-heading"> TOP 10 NẠP THẺ</div>
<div class="panel-body">
<?php
$result = mysqli_query($ketnoi,"SELECT * FROM `top_nap` ORDER BY `total_amount` DESC LIMIT 0,10");
if($result)
{
	$i = 1;
while($row = mysqli_fetch_assoc($result))
{
?>
 <li class="list-group-item"> TOP <?php echo $i.' : '; echo '<b style="color:red">'.$row['username'].'</b>'; ?> TỔNG NẠP : <b style="color:red"><?php echo number_format($row['total_amount']); ?> VNĐ</b></li>
<?php
$i++;
}
}
?>
</div>
</div>
</div>


</div>
<script type="text/javascript">
    $(document).ready(function() {
	setInterval(function(){
		$.get('chatbox.php', {
				}, function(data, status) {
					$("#chatbox").html(data);
				});
		},1e3);
	});
	
	
	$('#gui').click(function(){
				var mess = $('#tinhan').val();
				if (mess == '') {
					toarst("error","Vui Lòng Nhập Đầy Đủ Thông Tin","Thông Báo");
					return false;
				}
				$('#submit').prop('disabled', true)
				$.post('chatbox.php', {
					mess: mess,
				}, function(data, status) {
					$("#chatbox").html(data);
					$('#tinhan').val('');
				});
			}) 
			
$(document).keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
		var mess = $('#tinhan').val();
				if (mess == '') {
					toarst("error","Vui Lòng Nhập Đầy Đủ Thông Tin","Thông Báo");
					return false;
				}
				$('#submit').prop('disabled', true)
				$.post('chatbox.php', {
					mess: mess,
				}, function(data, status) {
					$("#chatbox").html(data);
					$('#tinhan').val('');
				});
	}
});
	
	
	
	
	
	
	
	
$('#mua').click(function(){
				var soluong = $('#soluong').val();
				var loai = $('#loai').val();
				if(soluong < 0){
					toarst("error","BUG CÁI LỒN MÀ BUG ĐỊT CON MẸ MÀY BIẾN NHÉ OK !!!","Thông Báo");
					return;
				}
				if (soluong == '') {
					toarst("error","Vui Lòng Nhập Đầy Đủ Thông Tin","Thông Báo");
					return false;
				}
				//$('#submit').prop('disabled', true);
				    $('#mua').addClass('btn btn-info').html('Đang Check Live...').attr('disabled','disabled');
				   
				$.post('mua_token.php', {
					soluong: soluong,
					loai:loai
				}, function(data, status) {
					$("#mess").html(data);
					//$('#submit').prop('disabled', false);
					$('#mua').removeClass('btn btn-info').addClass('btn btn-primary').html('Mua Tiếp').removeAttr('disabled');
				});
			});


$('#soluong').keyup(function(){
			var soluong = $('#soluong').val();
			var loai = $('#loai').val();
			if(soluong < 0){
				toarst("error","BUG CÁI LỒN MÀ Phuong DZ  OK !!!","Thông Báo");
				return;
			}
			if(loai == 1 && soluong > <?php echo $tongtoken1; ?>){
				toarst("error","Số Lượng Không Được Lớn Hơn Số Token Đang Có ở Hệ Thống","Thông Báo");
				return;
			}
			if(loai == 2 && soluong > <?php echo $tongtoken2; ?>){
				toarst("error","Số Lượng Không Được Lớn Hơn Số Token Đang Có ở Hệ Thống","Thông Báo");
				return;
			}
			if(loai == 3 && soluong > <?php echo $tongtoken3; ?>){
				toarst("error","Số Lượng Không Được Lớn Hơn Số Token Đang Có ở Hệ Thống","Thông Báo");
				return;
			}
			if(loai == 4 && soluong > <?php echo $tongtoken4; ?>){
				toarst("error","Số Lượng Không Được Lớn Hơn Số Token Đang Có ở Hệ Thống","Thông Báo");
				return;
			}
			if(loai == 5 && soluong > <?php echo $tongtoken5; ?>){
				toarst("error","Số Lượng Không Được Lớn Hơn Số Token Đang Có ở Hệ Thống","Thông Báo");
				return;
			}
                        if(loai == 1){
			var gia = <?php echo $gia1; ?>;
                        }
                        if(loai == 2){
			var gia = <?php echo $gia2; ?>;
                        }
                        if(loai == 3){
			var gia = <?php echo $gia3; ?>;
                        }
                        if(loai == 4){
			var gia = <?php echo $gia4; ?>;
                        }
                        if(loai == 5){
			var gia = <?php echo $gia5; ?>;
                        }
			var tien = gia * soluong;
			var vnd = <?php echo $vnd; ?>;
			if(tien > vnd){
				toarst("error","Bạn Không Đủ Tiền Để Mua Số Lượng Này","Thông Báo");
			}
			$('#tongthanhtoan').html(tien.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
			});
</script>
<?php
include('foot.php');
?>